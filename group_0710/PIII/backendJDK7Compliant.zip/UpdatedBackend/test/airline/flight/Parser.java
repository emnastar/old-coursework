package airline.flight;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;

/**
 * A simple parser until the CSV is ready.
 * 
 * @author Chris
 */
public class Parser {

	/**
	 * A list of flight information.
	 */
	private LinkedList<FlightInformation> flightInfoList;

	/**
	 * Parses the file from the location.
	 * 
	 * @param file
	 *            The file path to parse.
	 * 
	 * @throws IOException
	 *             If the file isn't found or an IO error occurs.
	 *             
	 * @throws ParseException
	 * 		If the line was invalid.
	 *  
	 * @throws NumberFormatException
	 * 		If the number could not be formatted due to corrupt string data. 
	 * */
	public Parser(String file) throws IOException, NumberFormatException, ParseException {
		flightInfoList = new LinkedList<>();
		List<String> lines = Files.readAllLines(Paths.get(file), 
				Charset.forName("ASCII"));
		for (String line : lines) {
			processLine(line);
		}
	}

	/**
	 * Processes the line of information.
	 * 
	 * @param line
	 *            The line to process.
	 *            
	 * @throws ParseException
	 * 		If the line was invalid.
	 *  
	 * @throws NumberFormatException
	 * 		If the number could not be formatted due to corrupt string data. 
	 */
	private void processLine(String line) throws NumberFormatException, ParseException {
		String[] tokens = line.split(",");
		flightInfoList.add(new FlightInformation(tokens[0], tokens[1],
				tokens[2], tokens[3], tokens[4], tokens[5],
				Double.parseDouble(tokens[6])));
	}

	/**
	 * Gets the information parsed.
	 * 
	 * @return This parsed information in list format.
	 */
	public LinkedList<FlightInformation> getFlightInfoList() {
		return flightInfoList;
	}
}
