package airline.flight;

import static org.junit.Assert.*;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Tests that the itinerary lists works.
 * 
 * @author Chris
 */
public class TestItineraryBuilder {

	/**
	 * The parsed flight info.
	 */
	private static LinkedList<FlightInformation> flightData;
	
	/**
	 * Tells other tests to fail if this is false.
	 */
	private static boolean textFileLoaded;
	
	/**
	 * The loaded data in an itinerary list format.
	 */
	private static ItineraryBuilder itList;
	
	/**
	 * Sets up the data.
	 * 
	 * @throws ParseException
	 * 		If the line was invalid.
	 *  
	 * @throws NumberFormatException
	 * 		If the number could not be formatted due to corrupt string data. 
	 */
	@BeforeClass
	public static void setupClass() throws NumberFormatException, ParseException {
		try {
			flightData = new Parser("res/test.txt").getFlightInfoList();
		} catch (IOException e) {
			textFileLoaded = false;
			return;
		}
		
		itList = new ItineraryBuilder(flightData.getFirst());
		itList.add(flightData.get(1));
		itList.add(flightData.get(2));
	}
	
	/**
	 * Tests that the last destination holds.
	 */
	@Test
	public void testLastDestination() {
		if (textFileLoaded) {
			fail("Cannot test, data not properly loaded.");
		}
		
		assertEquals(itList.getLastDestination(), "Venice");
	}
	
	/**
	 * Tests that the arrival time holds.
	 */
	@SuppressWarnings("deprecation")
	@Test
	public void testLastArrivalTime() {
		if (textFileLoaded) {
			fail("Cannot test, data not properly loaded.");
		}
		
		Date ldt = new Date(2015, 5, 11, 8, 23);
		assertEquals(itList.getLastArrivalTime(), ldt);
	}
	
	/**
	 * Tests that the data is properly getting added.
	 */
	@Test
	public void testProperDataAdded() {
		List<FlightInformation> fi = itList.getList();
		assertEquals(fi.size(), 3);
		assertEquals(fi.get(0).getOrigin(), "Toronto");
		assertEquals(fi.get(0).getDestination(), "Venice");
		assertEquals(fi.get(1).getOrigin(), "Toronto");
		assertEquals(fi.get(1).getDestination(), "London");
		assertEquals(fi.get(2).getOrigin(), "London");
		assertEquals(fi.get(2).getDestination(), "Venice");
	}
}
