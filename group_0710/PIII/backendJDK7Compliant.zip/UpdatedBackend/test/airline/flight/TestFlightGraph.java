package airline.flight;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the flight graph.
 * 
 * @author Chris
 */
public class TestFlightGraph {

	/**
	 * Loads the data.
	 * 
	 * @throws IOException
	 *             If any IO error occurs.
	 *             
	 * @throws ParseException
	 * 		If the line was invalid.
	 *  
	 * @throws NumberFormatException
	 * 		If the number could not be formatted due to corrupt string data. 
	 */
	@Test
	public void testLoading() throws IOException, NumberFormatException, ParseException {
		FlightGraph graph = new FlightGraph();
		for (FlightInformation fi : new Parser("res/test.txt").getFlightInfoList()) {
			graph.addFlight(fi);
		}
	}

	/**
	 * Tests that the flights work.
	 * 
	 * @throws IOException
	 *             If any IO error occurs.
	 *             
	 * @throws ParseException
	 * 		If the line was invalid.
	 *  
	 * @throws NumberFormatException
	 * 		If the number could not be formatted due to corrupt string data. 
	 */
	@Test
	public void testFlights() throws IOException, NumberFormatException, ParseException {
		FlightGraph graph = new FlightGraph();
		for (FlightInformation fi : new Parser("res/test.txt").getFlightInfoList()) {
			graph.addFlight(fi);
		}

		List<Itinerary> searched = graph.searchForItineraries("2015-05-10",
				"Toronto", "Venice");
		assertEquals(3, searched.size());
	}
}
