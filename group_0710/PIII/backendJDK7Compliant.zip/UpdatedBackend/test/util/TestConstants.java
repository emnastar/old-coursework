package util;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

/**
 * Tests the constants class methods.
 * 
 * @author Chris
 */
public class TestConstants {

	/**
	 * Tests the class can be parsed properly.
	 */
	@SuppressWarnings("deprecation")
	@Test
	public void testDateConverter() {
		Date date = Constants.parseDate("2014-03-12");
		assertEquals(2014, date.getYear());
		assertEquals(3, date.getMonth());
		assertEquals(12, date.getDate());
	}
	
	/**
	 * Tests that there is actual numbers.
	 */
	@Test(expected = NumberFormatException.class)
	public void testNumberCorruptionDate() {
		Constants.parseDate("2014-ab-12");
	}
	
	/**
	 * Test for nulls.
	 */
	@Test(expected = NullPointerException.class)
	public void testNull() {
		Constants.parseDate(null);
	}
}
