package airline.flight;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import util.Constants;
import static util.Assertions.*;

/**
 * A POJO to contain the flight information between one location and another.
 * The data is not considered sanitized, that is up to the graph to enforce. By
 * sanitization, that means that the data is correct, for example: If the origin
 * does not exist in a graph and never should, the graph should take steps to
 * prevent invalid data that could be in this node from sneaking in.
 * 
 * @author Chris
 */
public class FlightInformation {

	/**
	 * A formatter that takes the String date defined in the handout and makes a
	 * proper local date out of it.
	 */
	private static SimpleDateFormat dtFormatter =
			new SimpleDateFormat("yyyy-MM-dd HH:mm");

	/**
	 * The flight number.
	 */
	private String flightNumber;

	/**
	 * When the flight departs the origin.
	 */
	private Date departureDateTime;

	/**
	 * When the flight arrives at the destination.
	 */
	private Date arrivalDateTime;

	/**
	 * The name of the airline.
	 */
	private String airline;

	/**
	 * The origin name.
	 */
	private String origin;

	/**
	 * The destination name.
	 */
	private String destination;

	/**
	 * The cost in dollars (decimals are cents).
	 */
	private double cost;

	/**
	 * How many minutes it will take.
	 */
	private int travelTimeMinutes;

	/**
	 * Creates a new travel from raw text data by parsing the date times and
	 * passing it to the other constructor.
	 * 
	 * @param flightNumber
	 *            The flight number.
	 * 
	 * @param departureDateTime
	 *            The departure date time.
	 * 
	 * @param arrivalDateTime
	 *            The arrival date time.
	 * 
	 * @param airline
	 *            The airline name.
	 * 
	 * @param origin
	 *            The origin location name.
	 * 
	 * @param destination
	 *            The destination name.
	 * 
	 * @param cost
	 *            How much the cost is (dollars).
	 * 
	 * @param travelTimeMinutes
	 *            How many minutes the travel will take.
	 *            
	 * @throws ParseException
	 * 			If the string for the date is an invalid time. 
	 * 
	 * @throws DateTimeParseException
	 *             If the provided date time string for either departure or
	 *             arrival cannot properly be parsed.
	 * 
	 * @throws NullPointerException
	 *             If any argument is null.
	 * 
	 * @throws IllegalArgumentException
	 *             If the cost is negative, if the travel time is negative, or
	 *             if the departure date is after the arrival date.
	 */
	public FlightInformation(String flightNumber, String departureDateTime,
			String arrivalDateTime, String airline, String origin,
			String destination, double cost) throws ParseException {
		this(flightNumber, dtFormatter.parse(departureDateTime),
				dtFormatter.parse(arrivalDateTime), airline,
				origin, destination, cost);
	}

	/**
	 * Creates a new flight information from the data.
	 * 
	 * @param flightNumber
	 *            The flight number.
	 * 
	 * @param departureDateTime
	 *            The departure date time.
	 * 
	 * @param arrivalDateTime
	 *            The arrival date time.
	 * 
	 * @param airline
	 *            The airline name.
	 * 
	 * @param origin
	 *            The origin location name.
	 * 
	 * @param destination
	 *            The destination name.
	 * 
	 * @param cost
	 *            How much the cost is (dollars).
	 * 
	 * @throws NullPointerException
	 *             If any argument is null.
	 * 
	 * @throws IllegalArgumentException
	 *             If the cost is negative, if the travel time is negative, or
	 *             if the departure date is after the arrival date, or if the
	 *             destination equals the origin.
	 */
	public FlightInformation(String flightNumber,
			Date departureDateTime, Date arrivalDateTime,
			String airline, String origin, String destination, double cost) {
		checkNotNull(departureDateTime);
		checkNotNull(arrivalDateTime);
		checkNotNull(airline);
		checkNotNull(origin);
		checkNotNull(destination);
		checkArgument(cost >= 0);
		checkArgument(departureDateTime.before(arrivalDateTime));
		checkArgument(!origin.equals(destination));

		this.flightNumber = flightNumber;
		this.departureDateTime = departureDateTime;
		this.arrivalDateTime = arrivalDateTime;
		this.airline = airline;
		this.origin = origin;
		this.destination = destination;
		this.cost = cost;
		this.travelTimeMinutes = Constants.minutesBetweenDates(
				departureDateTime, arrivalDateTime);
	}

	/**
	 * Checks if the flight info provided is within some constant time as
	 * specified in Constants.java for this.
	 * 
	 * @param prevArrivalTime
	 *            The time of the previous arrival.
	 * 
	 * @return True if it's within the gap for the previous arrival time, or
	 *         false otherwise.
	 * 
	 * @throws NullPointerException
	 *             If the argument is null.
	 */
	public boolean withinDepartureTime(Date prevArrivalTime) {
		checkNotNull(prevArrivalTime);
		long diff = Constants.minutesBetweenDates(
				departureDateTime, arrivalDateTime);
		return diff >= 0 && diff <= Constants.MAX_MINUTES_PER_FLIGHT_GAP;
	}

	/**
	 * Checks if the provided date is the same day as the departure day.
	 * 
	 * @param date
	 *            The date to check if this departure date is on the same day as
	 *            what's provided.
	 * 
	 * @return True if this flight information is on the same day, false
	 *         otherwise.
	 * 
	 * @throws NullPointerException
	 *             If the argument is null.
	 */
	@SuppressWarnings("deprecation")
	public boolean isOnSameDepartureDayAs(Date date) {
		checkNotNull(date);
		int year = departureDateTime.getYear();
		int month = departureDateTime.getMonth();
		int day = departureDateTime.getDate();
		return (year == date.getYear() && month == date.getMonth()
				&& day == date.getDate());
	}

	/**
	 * Gets the flight number.
	 * 
	 * @return The flightnumber
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * Gets the departure date and time.
	 * 
	 * @return The departure date and time.
	 */
	public Date getDepartureDateTime() {
		return departureDateTime;
	}

	/**
	 * Gets the arrival date and time.
	 * 
	 * @return The arrival date and time.
	 */
	public Date getArrivalDateTime() {
		return arrivalDateTime;
	}

	/**
	 * Gets the airline name.
	 * 
	 * @return The airline name.
	 */
	public String getAirline() {
		return airline;
	}

	/**
	 * Gets the origin name.
	 * 
	 * @return The origin name.
	 */
	public String getOrigin() {
		return origin;
	}

	/**
	 * Gets the destination name.
	 * 
	 * @return The destination name.
	 */
	public String getDestination() {
		return destination;
	}

	/**
	 * Gets the cost of the flight.
	 * 
	 * @return The cost of the flight.
	 */
	public double getCost() {
		return cost;
	}

	/**
	 * Gets the travel time in minutes.
	 * 
	 * @return The travel time in minutes.
	 */
	public int getTravelTimeMinutes() {
		return travelTimeMinutes;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		String deptStr = dtFormatter.format(departureDateTime);
		String arrivalStr = dtFormatter.format(arrivalDateTime);
		String outputCost = String.format("%.2f", cost);
		return flightNumber + "," + deptStr + "," + arrivalStr + "," + airline
				+ "," + origin + "," + destination + "," + outputCost;
	}

	/**
	 * Converts this to the toString() format but instead it uses the date
	 * without any time (YYYY-MM-DD).
	 * 
	 * @return The string in date only form.
	 */
	@SuppressWarnings("deprecation")
	public String toStringDateOnly() {
		// Preprocess the data first so it's in a usable format for marking.
		String deptStr = String.format("%d-%02d-%02d",
				departureDateTime.getYear(), departureDateTime.getMonth(),
				departureDateTime.getDate());

		String arrivalStr = String.format("%d-%02d-%02d",
				arrivalDateTime.getYear(), arrivalDateTime.getMonth(),
				arrivalDateTime.getDate());

		String outputCost = String.format("%.2f", cost);

		return flightNumber + "," + deptStr + "," + arrivalStr + "," + airline
				+ "," + origin + "," + destination + "," + outputCost;
	}

	/**
	 * Prints out a String version with no cost.
	 * 
	 * @return A String version with no cost.
	 */
	public String toStringNoCost() {
		String deptStr = dtFormatter.format(departureDateTime);
		String arrivalStr = dtFormatter.format(arrivalDateTime);
		return flightNumber + "," + deptStr + "," + arrivalStr + "," + airline
				+ "," + origin + "," + destination;
	}
}
